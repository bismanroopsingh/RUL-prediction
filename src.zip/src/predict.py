import joblib
import pandas as pd

from src.data_loader import load_test_data
from src.feature_engineering import (
    add_cycle_features,
    rolling_features,
    remove_sensors,
)

# -----------------------------------------
# Load model and preprocessing artifacts
# -----------------------------------------

model = joblib.load("models/xgboost.pkl")

scaler = joblib.load("models/scaler.pkl")

feature_names = joblib.load("models/feature_names.pkl")

constant_sensors = joblib.load("models/constant_sensors.pkl")

# -----------------------------------------
# Load NASA Test Dataset
# -----------------------------------------

test = load_test_data("data/raw/test_FD001.txt")

# -----------------------------------------
# Feature Engineering
# -----------------------------------------

test = add_cycle_features(test)

test = rolling_features(test)

test = remove_sensors(test, constant_sensors)

# -----------------------------------------
# Keep only training features
# -----------------------------------------

X_test = test[feature_names]

# -----------------------------------------
# Scale
# -----------------------------------------

X_test_scaled = scaler.transform(X_test)

# -----------------------------------------
# Predict
# -----------------------------------------

predictions = model.predict(X_test_scaled)

test["Predicted_RUL"] = predictions

print(test[["engine_id", "cycle", "Predicted_RUL"]].tail())

# -----------------------------------------
# Save
# -----------------------------------------

test.to_csv(
    "outputs/test_predictions.csv",
    index=False
)

print("\nPredictions saved.")