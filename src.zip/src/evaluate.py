import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)

# -----------------------------------------
# Predictions
# -----------------------------------------

pred = pd.read_csv("outputs/test_predictions.csv")

# Last cycle of each engine
pred = pred.groupby("engine_id").last().reset_index()

# -----------------------------------------
# Ground Truth
# -----------------------------------------

truth = pd.read_csv(
    "data/raw/RUL_FD001.txt",
    header=None
)

truth.columns = ["Actual_RUL"]

# -----------------------------------------
# Metrics
# -----------------------------------------

mae = mean_absolute_error(
    truth["Actual_RUL"],
    pred["Predicted_RUL"]
)

rmse = mean_squared_error(
    truth["Actual_RUL"],
    pred["Predicted_RUL"]
) ** 0.5

r2 = r2_score(
    truth["Actual_RUL"],
    pred["Predicted_RUL"]
)

print("=" * 50)
print("NASA Official Test Results")
print("=" * 50)

print(f"MAE  : {mae:.2f}")
print(f"RMSE : {rmse:.2f}")
print(f"R²   : {r2:.4f}")

# -----------------------------------------
# Plot
# -----------------------------------------

plt.figure(figsize=(8, 6))

plt.scatter(
    truth["Actual_RUL"],
    pred["Predicted_RUL"],
    alpha=0.7
)

plt.plot(
    [0, truth["Actual_RUL"].max()],
    [0, truth["Actual_RUL"].max()],
    "r--"
)

plt.xlabel("Actual RUL")
plt.ylabel("Predicted RUL")

plt.title("Official NASA Test Set")

plt.grid(True)

plt.show()