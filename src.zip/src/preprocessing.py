import pandas as pd


def add_rul(df):
    """
    Adds Remaining Useful Life (RUL) column
    """

    max_cycle = (
        df.groupby("engine_id")["cycle"]
        .max()
        .reset_index()
    )

    max_cycle.columns = ["engine_id", "max_cycle"]

    df = df.merge(max_cycle, on="engine_id")

    df["RUL"] = df["max_cycle"] - df["cycle"]

    df.drop("max_cycle", axis=1, inplace=True)

    return df