import pandas as pd

COLUMNS = [
    "engine_id",
    "cycle",
    "op_setting_1",
    "op_setting_2",
    "op_setting_3"
]

for i in range(1, 22):
    COLUMNS.append(f"sensor_{i}")


def load_training_data(path):
    df = pd.read_csv(
        path,
        sep=r"\s+",
        header=None
    )

    # Remove empty columns
    df = df.iloc[:, :26]

    df.columns = COLUMNS

    return df


def load_test_data(path):
    df = pd.read_csv(
        path,
        sep=r"\s+",
        header=None
    )

    df = df.iloc[:, :26]

    df.columns = COLUMNS

    return df


def load_rul(path):
    rul = pd.read_csv(path, header=None)
    rul.columns = ["RUL"]
    return rul

def load_test_rul(path):
    """
    Load ground truth RUL for the test set.
    """
    rul = pd.read_csv(path, header=None)

    rul.columns = ["RUL"]

    return rul