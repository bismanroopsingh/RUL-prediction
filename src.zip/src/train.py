# import joblib
# import mlflow
# import mlflow.xgboost
# import pandas as pd
# import xgboost as xgb

# from sklearn.model_selection import train_test_split
# from sklearn.metrics import (
#     mean_absolute_error,
#     mean_squared_error,
#     r2_score,
# )

# # ====================================================
# # Load Processed Data
# # ====================================================

# X = pd.read_csv("data/processed/X_train.csv")
# y = pd.read_csv("data/processed/y_train.csv").values.ravel()

# # ====================================================
# # Train Validation Split
# # ====================================================

# X_train, X_valid, y_train, y_valid = train_test_split(
#     X,
#     y,
#     test_size=0.2,
#     random_state=42,
# )

# # ====================================================
# # Start MLflow
# # ====================================================

# mlflow.set_experiment("NASA_RUL_XGBoost")

# with mlflow.start_run():

#     model = xgb.XGBRegressor(
#         n_estimators=500,
#         learning_rate=0.05,
#         max_depth=6,
#         subsample=0.8,
#         colsample_bytree=0.8,
#         objective="reg:squarederror",
#         random_state=42,
#         n_jobs=-1,
#     )

#     model.fit(
#         X_train,
#         y_train,
#         eval_set=[(X_valid, y_valid)],
#         verbose=False,
#     )

#     predictions = model.predict(X_valid)

#     mae = mean_absolute_error(y_valid, predictions)
#     rmse = mean_squared_error(y_valid, predictions) ** 0.5
#     r2 = r2_score(y_valid, predictions)

#     print(f"MAE  : {mae:.2f}")
#     print(f"RMSE : {rmse:.2f}")
#     print(f"R2   : {r2:.4f}")

#     mlflow.log_metric("MAE", mae)
#     mlflow.log_metric("RMSE", rmse)
#     mlflow.log_metric("R2", r2)

#     mlflow.xgboost.log_model(
#     xgb_model=model,
#     name="model")

# joblib.dump(model, "models/xgboost.pkl")

# print("Model saved successfully.")


import joblib
import pandas as pd
import xgboost as xgb

from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score

# Load processed training data
X = pd.read_csv("data/processed/X_train.csv")
y = pd.read_csv("data/processed/y_train.csv").values.ravel()

print("Training samples:", X.shape)

model = xgb.XGBRegressor(
    n_estimators=500,
    learning_rate=0.05,
    max_depth=6,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42,
    objective="reg:squarederror",
    n_jobs=-1
)

from src.tune import XGBoostTuner

groups = xgb.train["engine_id"]

tuner = XGBoostTuner(
    X,
    y,
    groups
)

study = tuner.optimize(
    n_trials=30
)

print(study.best_params)

pred = model.predict(X)

print("Training Metrics")
print("MAE :", mean_absolute_error(y, pred))
print("RMSE:", mean_squared_error(y, pred) ** 0.5)
print("R²  :", r2_score(y, pred))

joblib.dump(model, "models/xgboost.pkl")

print("Model Saved")