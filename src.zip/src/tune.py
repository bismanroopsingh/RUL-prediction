import optuna
import numpy as np
import xgboost as xgb

from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_squared_error


class XGBoostTuner:

    def __init__(self, X, y, groups):

        self.X = X
        self.y = y
        self.groups = groups

    def objective(self, trial):

        params = {

            "objective": "reg:squarederror",

            "n_estimators": trial.suggest_int(
                "n_estimators",
                300,
                1200
            ),

            "learning_rate": trial.suggest_float(
                "learning_rate",
                0.01,
                0.2,
                log=True
            ),

            "max_depth": trial.suggest_int(
                "max_depth",
                3,
                10
            ),

            "subsample": trial.suggest_float(
                "subsample",
                0.6,
                1.0
            ),

            "colsample_bytree": trial.suggest_float(
                "colsample_bytree",
                0.6,
                1.0
            ),

            "min_child_weight": trial.suggest_int(
                "min_child_weight",
                1,
                10
            ),

            "gamma": trial.suggest_float(
                "gamma",
                0,
                5
            ),

            "random_state": 42,

            "n_jobs": -1

        }

        gkf = GroupKFold(n_splits=5)

        scores = []

        for train_idx, val_idx in gkf.split(
                self.X,
                self.y,
                self.groups):

            X_train = self.X.iloc[train_idx]

            X_val = self.X.iloc[val_idx]

            y_train = self.y.iloc[train_idx]

            y_val = self.y.iloc[val_idx]

            model = xgb.XGBRegressor(**params)

            model.fit(X_train, y_train)

            pred = model.predict(X_val)

            rmse = np.sqrt(
                mean_squared_error(
                    y_val,
                    pred
                )
            )

            scores.append(rmse)

        return np.mean(scores)

    def optimize(self, n_trials=30):

        study = optuna.create_study(
            direction="minimize"
        )

        study.optimize(
            self.objective,
            n_trials=n_trials
        )

        return study