import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import joblib


class FeatureEngineer:

    def __init__(
        self,
        rul_cap=125,
        rolling_window=5,
        lag_steps=3
    ):

        self.rul_cap = rul_cap
        self.rolling_window = rolling_window
        self.lag_steps = lag_steps

        self.scaler = StandardScaler()

        self.selected_sensors = [
            "sensor_2",
            "sensor_3",
            "sensor_4",
            "sensor_7",
            "sensor_8",
            "sensor_9",
            "sensor_11",
            "sensor_12",
            "sensor_13",
            "sensor_15",
            "sensor_17",
            "sensor_20",
            "sensor_21",
        ]

    ####################################################
    # RUL Capping
    ####################################################

    def cap_rul(self, df):

        if "RUL" in df.columns:
            df["RUL"] = df["RUL"].clip(
                upper=self.rul_cap
            )

        return df

    ####################################################
    # Cycle Features
    ####################################################

    def cycle_features(self, df):

        max_cycle = (
            df.groupby("engine_id")["cycle"]
            .transform("max")
        )

        df["life_percentage"] = (
            df["cycle"] / max_cycle
        )

        df["cycle_squared"] = (
            df["cycle"] ** 2
        )

        return df

    ####################################################
    # Lag Features
    ####################################################

    def lag_features(self, df):

        for sensor in self.selected_sensors:

            for lag in range(
                1,
                self.lag_steps + 1
            ):

                df[
                    f"{sensor}_lag_{lag}"
                ] = (
                    df.groupby("engine_id")[sensor]
                    .shift(lag)
                )

        return df

    ####################################################
    # Rolling Features
    ####################################################

    def rolling_features(self, df):

        for sensor in self.selected_sensors:

            grouped = (
                df.groupby("engine_id")[sensor]
            )

            df[
                f"{sensor}_mean"
            ] = grouped.transform(
                lambda x:
                x.rolling(
                    self.rolling_window,
                    min_periods=1
                ).mean()
            )

            df[
                f"{sensor}_std"
            ] = grouped.transform(
                lambda x:
                x.rolling(
                    self.rolling_window,
                    min_periods=1
                ).std()
            )

            df[
                f"{sensor}_min"
            ] = grouped.transform(
                lambda x:
                x.rolling(
                    self.rolling_window,
                    min_periods=1
                ).min()
            )

            df[
                f"{sensor}_max"
            ] = grouped.transform(
                lambda x:
                x.rolling(
                    self.rolling_window,
                    min_periods=1
                ).max()
            )

        return df

    ####################################################
    # Delta Features
    ####################################################

    def delta_features(self, df):

        for sensor in self.selected_sensors:

            df[
                f"{sensor}_delta"
            ] = (
                df.groupby("engine_id")[sensor]
                .diff()
            )

        return df

    ####################################################
    # EMA Features
    ####################################################

    def ema_features(self, df):

        for sensor in self.selected_sensors:

            df[
                f"{sensor}_ema"
            ] = (
                df.groupby("engine_id")[sensor]
                .transform(
                    lambda x:
                    x.ewm(
                        span=5,
                        adjust=False
                    ).mean()
                )
            )

        return df

    ####################################################
    # Missing Values
    ####################################################

    def fill_missing(self, df):

        df = df.fillna(method="bfill")

        df = df.fillna(0)

        return df

    ####################################################
    # Scaling
    ####################################################

    def fit_scaler(self, X):

        self.scaler.fit(X)

        joblib.dump(
            self.scaler,
            "models/scaler.pkl"
        )

    def transform(self, X):

        return self.scaler.transform(X)

    ####################################################
    # Complete Pipeline
    ####################################################

    def engineer(self, df):

        df = self.cap_rul(df)

        df = self.cycle_features(df)

        df = self.lag_features(df)

        df = self.rolling_features(df)

        df = self.delta_features(df)

        df = self.ema_features(df)

        df = self.fill_missing(df)

        return df